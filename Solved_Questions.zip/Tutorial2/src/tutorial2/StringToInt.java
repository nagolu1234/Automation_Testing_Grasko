package tutorial2;

public class StringToInt {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String a="1000";  
		int i=Integer.parseInt(a);  
		System.out.println(i);  

	}

}
