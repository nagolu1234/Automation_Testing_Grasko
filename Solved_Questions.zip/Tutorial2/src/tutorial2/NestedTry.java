package tutorial2;

public class NestedTry {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			int a[] = {1,2,3,4,5};
			System.out.println(a[6]);
			try {
				int x = a[2] /0;
			}
			catch (ArithmeticException e2) {
				System.out.println("Divison by zero is not possible");
			}
		}
		catch (ArrayIndexOutOfBoundsException e1) {
			System.out.println("ArrayIndexOutOfBoundsException");
			System.out.println("Element at such index not exist");


			
			
		}

	}

}
