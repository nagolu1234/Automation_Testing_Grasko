package tutorial2;
import java.util.Scanner;
public class SumOfDigitsOfAnInteger {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int number, digit, sum = 0;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number to evaluate");
		number = sc.nextInt();
		while (number>0) {
			digit = number%10;
			sum = sum+digit;
			number = number/10;
		}
		System.out.println("The sum of the digits is:" + sum);
		

	}

}
