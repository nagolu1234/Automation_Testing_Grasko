import java.util.*;
public class ShuffleList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<String> list_colour = new ArrayList<String>();
		list_colour.add("Red");
		list_colour.add("Blue");
		list_colour.add("Black");
		list_colour.add("Orange");
		list_colour.add("Violet");
		System.out.println(list_colour); // Console_print_list_of_above_colors
		Collections.shuffle(list_colour);
		System.out.println("list_after_shuffle:" + list_colour); // Console_print_shuffle_list_of_above_colors

		}

	}


