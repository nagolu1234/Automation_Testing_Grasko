import java.util.*;
public class EmptyOrNot {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<String> list_colour = new ArrayList<String>();
		list_colour.add("Red");
		list_colour.add("Blue");
		list_colour.add("Black");
		System.out.println(list_colour); // Console_print_list_of_above_colors
		if (list_colour.isEmpty()) {
			System.out.println("The list is empty");
		}
		
		else {
			System.out.println("The list is not empty");
		}
	}

}
