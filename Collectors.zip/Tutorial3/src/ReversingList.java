import java.util.*;
public class ReversingList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<String> list_colour = new ArrayList<String>();
		list_colour.add("Red");
		list_colour.add("Blue");
		list_colour.add("Black");
		System.out.println(list_colour); // Console_print_list_of_above_colors
		Collections.reverse(list_colour); // Revresing_the_list_elements_using_reverse_method
		Iterator itr = list_colour.iterator();
		while (itr.hasNext()) {
			System.out.println(itr.next());
		}

	}

}
