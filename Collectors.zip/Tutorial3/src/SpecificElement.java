import java.util.*;
public class SpecificElement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<String> list_colour = new ArrayList<String>();
		list_colour.add("Red");
		list_colour.add("Blue");
		list_colour.add("Black");
		System.out.println(list_colour); // Console_print_list_of_above_colors
		list_colour.add(1, "Orange"); // Adding_colour_ornage_in_the_list_at_specific_Index_1
		Iterator itr = list_colour.iterator();
		while (itr.hasNext()) {
			System.out.println(itr.next());
		}

	}

}
