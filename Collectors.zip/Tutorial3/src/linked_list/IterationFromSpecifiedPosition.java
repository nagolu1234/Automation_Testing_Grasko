package linked_list;

import java.util.Iterator;
import java.util.LinkedList;

public class IterationFromSpecifiedPosition {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedList<String> l_colour = new LinkedList<String>();
		l_colour.add("Red");
		l_colour.add("Blue");
		l_colour.add("Black");
		l_colour.add("orange");
		System.out.println(l_colour);
	    Iterator itr = l_colour.listIterator(1); //Iterator_Iterate_from_Index1_in_the_linked_list
		while (itr.hasNext()) {             
			System.out.println(itr.next());
		}

	}

}
