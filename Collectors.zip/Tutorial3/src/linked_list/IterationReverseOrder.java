package linked_list;
import java.util.Iterator;
import java.util.LinkedList;

public class IterationReverseOrder {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedList<String> l_colour = new LinkedList<String>();
		l_colour.add("Red");
		l_colour.add("Blue");
		l_colour.add("Black");
		l_colour.add("orange");
		System.out.println("Original_linked_list:" +l_colour);
		
		Iterator r = l_colour.descendingIterator();
		System.out.println("Iterated_elements_in_reverse_order:");
		while (r.hasNext()) {
			System.out.println(r.next());
		}
			
	}

}
