package linked_list;
import java.util.LinkedList;
public class SpecifiedElementLinkedList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedList<String> l_colour = new LinkedList<String>();
		l_colour.add("Red");
		l_colour.add("Blue");
		l_colour.add("Black");
		System.out.println(l_colour);
	    l_colour.offerLast("Yellow");
	    System.out.println(l_colour);
	}

}
