package linked_list;
import java.util.*;
public class IterationFromStartToEnd {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<String> l_colour = new LinkedList<String>();
		l_colour.add("Red");
		l_colour.add("Blue");
		l_colour.add("Black");
		l_colour.add("orange");
		System.out.println(l_colour);
	    Iterator itr = l_colour.iterator(); //Iterator_Iterate__by_default_the_elements_form_start_to_end_in_the_linked_list
		while (itr.hasNext()) {             
			System.out.println(itr.next());
		}

	}

}
