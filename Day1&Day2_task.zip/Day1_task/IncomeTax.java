package day1;

import java.util.*;

public class IncomeTax {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("enter the salary:");
		Scanner sc = new Scanner(System.in);
		int salary = sc.nextInt();
		int tax_amount = 0;
		if(salary<=50000) {
			tax_amount = 0;
		}
		if(salary>50000 && salary <= 60000) {
			tax_amount = (salary-50000)*10/100;
		}
		if(salary>60000 && salary <= 150000) {
			tax_amount = (salary-50000)*20/100;
		}
		if(salary>150000) {
			tax_amount = (salary-50000)*30/100;
		}
		System.out.println("The Tax is:"+tax_amount);
	}

}
