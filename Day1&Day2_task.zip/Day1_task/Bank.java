
class NewBank{
	int accno;
	String name = null;
	int balance;
	
	void setData( int a , String n, int b) {
		accno = a;
		name = n;
		balance = b;
	}
	
	void deposit(int amount) {
		balance = balance +amount;
	}
	void withdraw(int amount) {
		if(amount>balance) {
			System.out.println("Insufficient fund");
		}
		else
		balance = balance - amount;
	}
	
	void display() {
	System.out.println("Your accno :" + accno);
	System.out.println("Your name :" + name);
	System.out.println("Your balance :" + balance);
		
	}
}
public class Bank {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		NewBank nb = new NewBank();
		nb.setData(1752722909, "Ramesh", 100000);
		nb.deposit(60000);
		nb.withdraw(8000);
		nb.display();
	}

}
