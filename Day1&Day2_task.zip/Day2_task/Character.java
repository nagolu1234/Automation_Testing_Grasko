package day2;

public class Character {
	
		void printn(char c,int n) {
		System.out.println("a , 10");
		}
		void printn(int n,char c) {
		System.out.println("10 , a");
		}
		
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Character nc=new Character();
		nc.printn('a', 11);
		nc.printn(3, 'd');
	}

}


