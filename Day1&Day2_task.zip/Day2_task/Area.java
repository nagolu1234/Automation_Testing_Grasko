package day2;

public class Area {
 void square(int x) {
	 System.out.println("The area of square is"+(x*x));
 }
void square(int x,int y) {
	 System.out.println("The area of rectangle is"+(x*y));
 }
 
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Area a = new Area();
		a.square(4);
		a.square(2,3);
	}

}
