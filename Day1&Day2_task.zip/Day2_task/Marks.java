package day2;


abstract class Mark{
	public abstract double getPercentage();
}
class A extends Mark{
	int mark_1,mark_2,mark_3;
	A(int m1,int m2,int m3){
		mark_1=m1;
		mark_2=m2;
		mark_3=m3;

	}
	public double getPercentage() {
		double percent = ((mark_1+mark_2+mark_3)/300.0)*100;
		return percent;
	}
}
class B extends Mark{
	int mark_1,mark_2,mark_3,mark_4;
	B(int m1,int m2,int m3,int m4){
		mark_1=m1;
		mark_2=m2;
		mark_3=m3;
		mark_4 = m4;
	}
	public double getPercentage() {
		double percent = ((mark_1+mark_2+mark_3+mark_4)/400.0)*100;
		return percent;
	}
}
public class Marks {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A a = new A(90,56,78);
		B b = new B(78,90,67,89);
		System.out.println("The percentage of Student A is:" +a.getPercentage());
		System.out.println("The percentage of Student B is:" +b.getPercentage());

	}

}
