 package day2;

class Bank0{

	int getBalance()
		{ 
		return 0;
		}

	}

class Bankh extends Bank0{

int getBalance(int balance)
   { 
	return balance; 
	}

}

class Banki extends Bank0{

int getBalance(int balance) 
{
	return balance;
	}

}

class Bankj extends Bank0{

int getBalance(int balance)
{ 
	return balance;
	}

}

public class practice{

public static void main(String args[]) {

Bankh a = new Bankh();

Banki b = new Banki(); 
Bankj c = new Bankj();

System.out.println("$" +a.getBalance(1000));

System.out.println("$" +b.getBalance(1500));

System.out.println("$" +c.getBalance(2000));

}

}
